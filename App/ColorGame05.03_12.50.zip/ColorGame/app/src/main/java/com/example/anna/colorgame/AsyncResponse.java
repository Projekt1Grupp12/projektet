package com.example.anna.colorgame;

public interface AsyncResponse {
    void postResult(String result);
}
